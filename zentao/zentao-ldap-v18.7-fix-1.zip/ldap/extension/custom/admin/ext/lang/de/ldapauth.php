<?php
$lang->admin->menuList->system['subMenu']['ldap'] = array('link' => 'LDAP|ldap|index', 'subModule' => 'ldap');
$lang->admin->menuList->system['menuOrder']['55'] = 'ldap';
$lang->admin->menuList->system['dividerMenu']    .= 'ldap,';